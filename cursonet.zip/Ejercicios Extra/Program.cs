﻿//   Crear 3 variables numéricas con el valor que tu quieras
//   y en otra variable numérica guardar el valor de la suma de
//   las 3 anteriores. Mostrar por consola.
Console.Clear();

Console.WriteLine("Este programa sumara 3 numeros.");
Console.WriteLine();

// Definicion de variables
int numeroUno = 10;
int numeroDos = 25;
int numeroTres = 2;

// Operacion

int suma = numeroUno + numeroDos + numeroTres;

// Print del Resultado

Console.WriteLine("La suma es igual a: " + suma);
Console.WriteLine("Programa finalizado, presione cualquier tecla para salir.");

Console.ReadKey();