﻿Console.Clear();

for (int contador = 1; contador <= 100; contador++)
{
    Console.WriteLine($"N° {contador}");
}