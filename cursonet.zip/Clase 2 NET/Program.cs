﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// Datos Numericos

byte numero_byte = 0;
int numero_integer = 0;
long numero_long = 200;
double numero_double = 300;
decimal numero_decimal = 0.5;
float numero_float = 400;

// datos logico
bool dato_bool = false;//0

// datos de texto
string dato_string = "texto de prueba numero 1";

// Instruccion de salida - output
Console.WriteLine(dato_string);

// Instruccion de Entrada - Input
dato_string = Console.ReadLine();


dato_string = "texto modificado";

Console.WriteLine(dato_string);