﻿
// Borra la pantalla
Console.Clear();

// Pedimos al usuario que introduzca su nombre
Console.WriteLine("Hola, Ingrese su nombre:");

// Leemos el nombre del usuario
string nombre;
nombre = Console.ReadLine();

// Mostramos el Nombre
Console.WriteLine("Hola " + nombre + ", este es mi segundo programa.");
Console.WriteLine("Gonza se la come");


