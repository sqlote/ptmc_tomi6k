﻿Console.Clear();

Console.WriteLine("Este programa la superficie de un rectangulo");
Console.WriteLine();

Console.WriteLine("Ingrese la base del rectangulo");
string baseRectanguloTexto = Console.ReadLine();
double baseRectangulo = double.Parse(baseRectanguloTexto);

