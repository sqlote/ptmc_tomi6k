﻿Console.Clear();

int contador = 0; //indicamos valor inicial de donde se parte a una variable

    while (contador <= 100) // hasta donde se quiere llegar
{
    Console.WriteLine(contador);   //muestre el nro actual
    contador++;   // y le sume uno al numero actual

}